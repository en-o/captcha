const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true,
  devServer: {
      host: 'localhost',
      port: 8080,
      proxy: {
        '/api': {
          target: 'http://localhost:8080',// 要跨域的域名
          changeOrigin: true, // 是否开启跨域
          pathRewrite: {   //重写路径
            '^/api': '' 
        }
      }
    }
  }
})
