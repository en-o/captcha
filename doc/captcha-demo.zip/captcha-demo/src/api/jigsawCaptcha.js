import axios from 'axios'
// 超时时间
axios.defaults.timeout = 30000
// 跨域请求，允许保存cookie
axios.defaults.withCredentials = true

let base = '/api'
/**
 * 验证码
 */
export const getCodeImg = () => {
  return axios({
    url: `${base}/captcha/slide`,
    method: 'get'
  })
}

/**
 * 拼图校验
 */
export const checkCaptcha = form => {
  console.log("拼图校验:")
  console.log(form.value)
  return axios({
    url: `${base}/verify/captcha/${form.value}`,
    method: 'get'
  })
}
