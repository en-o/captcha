<template>
  <div class="login-container">
    <el-form ref="loginForm" :model="loginForm" :rules="loginRules" class="login-form" auto-complete="on" label-position="left">
      <!--滑块验证-->
      <el-dialog title="请拖动滑块完成拼图" width="360px" :visible.sync="isShowSliderVerify" :close-on-click-modal="false" @closed="refresh" append-to-body>
        <slider-verify ref="sliderVerify" @success="onSuccess" @fail="onFail" @again="onAgain"/>
      </el-dialog>
      <el-button :loading="loading" round style="width:100%;margin-bottom:30px;" @click.native.prevent="handleLogin">获取和验证</el-button>
    </el-form>
  </div>
</template>
<script>
  import sliderVerify from './components/sliderVerify.vue';
  import { checkCaptcha } from '@/api/jigsawCaptcha'

export default {
  name: 'App',
  components: {
    sliderVerify,
  },
  data() {
    return {
      loginForm: {
        userName: '',
        passWord: '',
        // 随机字符串
        nonceStr: '',
        // 验证值
        value: '',
      },
     
      loading: false,
      // 是否显示滑块验证
      isShowSliderVerify: false,
    }
  },
  methods: {
    /* 提交*/
    handleLogin() {
      let self = this;
      self.$refs.loginForm.validate((flag) => {
        self.isShowSliderVerify = flag;
      });
    },
    /* 验证*/
    login() {
      let self = this;
      self.loading = true;
      // {nonceStr: this.nonceStr, value: moveLength}
      checkCaptcha(self.loginForm).then((response) => {
        console.log("校验返回：")
        console.log(response.data)
        self.$refs.sliderVerify.verifySuccessEvent();
        self.message('success', response.data.message);
        this.$router.push({ path: this.redirect || '/' })
      }).catch(() => {
         self.$refs.sliderVerify.verifyFailEvent();
      }).finally(() => {
        self.isShowSliderVerify = false;
      })
    },
    /* 滑动验证成功*/
    onSuccess(captcha) {
      Object.assign(this.loginForm, captcha);
      this.login();
    },
    // /* 滑动验证失败*/
    // onFail(msg) {
    //   console.log(msg)
    //   this.message('error', msg || '验证失败，请控制拼图对齐缺口');
    // },
    /* 滑动验证异常*/
    onAgain() {
      this.message('error', '滑动操作异常，请重试');
    },
    /* 刷新验证码*/
    refresh() {
      this.$refs.sliderVerify.refresh();
    },
    /* 提示弹框*/
    message(type, message) {
      this.$message({
        showClose: true,
        type: type,
        message: message,
        duration: 1500,
      });
    },

  },

}
</script>